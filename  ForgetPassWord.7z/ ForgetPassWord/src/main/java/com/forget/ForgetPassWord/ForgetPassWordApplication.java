package com.forget.ForgetPassWord;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForgetPassWordApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForgetPassWordApplication.class, args);
	}

}
