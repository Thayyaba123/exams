import { CompareValidatorsDirective } from './compare-validators.directive';

describe('CompareValidatorsDirective', () => {
  it('should create an instance', () => {
    const directive = new CompareValidatorsDirective();
    expect(directive).toBeTruthy();
  });
});
