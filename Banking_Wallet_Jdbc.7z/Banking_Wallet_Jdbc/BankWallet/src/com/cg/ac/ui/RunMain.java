package com.cg.ac.ui;

import java.util.Random;
import java.util.Scanner;
import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;
import com.cg.ac.service.AccountService;
import com.cg.ac.service.AccountServiceImp;

public class RunMain {
	static AccountService acservice=null;
	static Scanner scan=null;
	static Account ac=null;
	static int choice;
	static int randomAc;
	static String accountNo,accountNo1;
	static double amount;

	public static void main(String[] args) {
		 
		acservice= new AccountServiceImp();
		scan= new Scanner(System.in);

		do {
			System.out.println("Enter your choice:");
			System.out.println("1. CREATE ACCOUNT");
			System.out.println("2. SHOW BALANCE");
			System.out.println("3. DEPOSITE");
			System.out.println("4. WITHDRAW");
			System.out.println("5. TRANSFER MONEY");
			System.out.println("6. PRINT TRANSACTION");
			System.out.println("7. EXIT");
			scan = new Scanner(System.in);
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				
				break;
			case 2:
				showBalance();
				break;
			case 3:
				
				deposite(accountNo,amount);
				break;
			case 4:
				withDraw(accountNo,amount);
				break;
			case 5:
				fundTransfer(accountNo,accountNo1,amount);
				break;
			case 6:

				break;
			case 7:
				System.out.println("Thank you for banking with us.");
				System.exit(0);
				break;

			default:
				break;
			}
		} while (choice != 7);
	}

	

	



	private static void createAccount() {
		System.out.println("Enter Your name:");
		String name = scan.next();
		try {
			if (acservice.validateName(name)) {

				System.out.println("Enter initial balance:");
				double amount = scan.nextDouble();
				try {
					if (true) {
						System.out.println("Enter contact no:");
						String contact = scan.next();

						try {
							if (acservice.validateContact(contact)) {
								System.out.println("Enter account type(saving or current only):");
								String acType = scan.next();

								try {
									if (acservice.validateAccouuntType(acType)) {
										Random rand = new Random();
										randomAc = rand.nextInt(900000000) + 1000000000;
										String acNo=Integer.toString(randomAc);
										
										System.out.println("Enter PAN No: ");
										String pan= scan.next();
										System.out.println("Enter Adhar No: ");
										String adhar= scan.next();
										Account account = new Account(acNo,name, amount, contact, acType);
										Customer customer= new Customer(name, pan, adhar, acNo, contact);
										
										acservice.createAccount(account,customer);
									

									}
								} catch (AccountException e) {

								}

							}

						} catch (AccountException e) {

						}
					}

				}

				catch (Exception e) {

				}
			}
		} catch (AccountException e) {

		}

	}
	private static void showBalance() {
		System.out.println("Enter 10 digit account no:");
		String accountNo=scan.next();
		try {
			ac=acservice.showBalance(accountNo);
			
			
		} catch (Exception e) {
			
		}
		
	}
		
	public static void deposite(String accountNo, double amount)
	{
		try {
			System.out.println("Enter account no:");
			accountNo=scan.next();
			System.out.println("Enter amount to deposite:");
			amount=scan.nextDouble();
			ac=acservice.deposite(accountNo, amount);
			
			} catch (AccountException e) {
				
				e.printStackTrace();
			}
	}
	public static void withDraw(String accountNo2, double amount2) {
		try {
		System.out.println("Enter account no:");
		accountNo=scan.next();
		System.out.println("Enter amount to withdraw:");
		amount=scan.nextDouble();
		ac=acservice.withDraw(accountNo, amount);
		
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public static void fundTransfer(String accountNo,String accountNo1, double amount)
	{
		try {
		System.out.println("Enter sender account no:");
		accountNo=scan.next();
		System.out.println("Enter receiver account no:");
		accountNo1=scan.next();
		System.out.println("Enter amount to send:");
		amount= scan.nextDouble();
		ac=acservice.fundTransfer(accountNo,accountNo1,amount);
	
		
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
		
		
	}

		
	}


