package dao;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import bean.User;

@Repository("userRepository")
public interface UserRepository JpaRepository<User, Long>{
	Optional<User> findByEmail(String email);
	 Optional<User> findByResetToken(String resetToken);
}
