import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
   // password: ['', Validators.required]
  }
username:string;
  oldPasswordDb: string = "asad21";
  oldPassword: string;
  newPassword: string;
  newConfirmPassword: string;

  changePassword() {
  
    if (this.oldPassword == this.oldPasswordDb) {
      if ((this.newPassword.length <= 8)||(this.newPassword=="")) {
        alert("New pwd must be greater than 8 or enter");
         if(this.newConfirmPassword!=this.newPassword)
      {
        alert("enter password mismatch");
      }
      if(this.newConfirmPassword!=this.newPassword)
      {
        alert("enter password mismatch");
      }
      }
      else {
        this.oldPasswordDb = this.newPassword;
      }
     

    }
    else {
      console.log("Wrong Password");
      alert("old  password Wrong");
    }
  }
}
