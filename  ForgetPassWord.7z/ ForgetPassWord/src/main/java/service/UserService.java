package service;

import java.util.Optional;

import bean.User;

public interface UserService {
	public Optional<User> findUserByEmail(String email);
    public Optional<User> findUserByResetToken(String resetToken);
    public void save(User user);
}
